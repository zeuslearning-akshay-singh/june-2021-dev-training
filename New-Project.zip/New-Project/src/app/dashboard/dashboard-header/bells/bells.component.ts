import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bells',
  templateUrl: './bells.component.html',
  styleUrls: ['./bells.component.scss']
})
export class BellsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
