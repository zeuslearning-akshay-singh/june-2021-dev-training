export interface coure{
    status:string;
    image:string,
    topic:string,
    subject:string,
    grade:number,
    extragrade:string ,
    syllabus : boolean,
        units: number,
        lessons: number,
        topics:number,
    class: boolean,
    classes:string,
    students:string,
    duration:string
    
} 