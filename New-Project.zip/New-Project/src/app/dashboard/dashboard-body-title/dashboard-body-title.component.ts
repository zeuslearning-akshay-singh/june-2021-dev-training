import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-body-title',
  templateUrl: './dashboard-body-title.component.html',
  styleUrls: ['./dashboard-body-title.component.scss']
})
export class DashboardBodyTitleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
