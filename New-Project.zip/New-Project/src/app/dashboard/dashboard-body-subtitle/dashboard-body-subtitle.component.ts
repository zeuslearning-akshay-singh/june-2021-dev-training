import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-body-subtitle',
  templateUrl: './dashboard-body-subtitle.component.html',
  styleUrls: ['./dashboard-body-subtitle.component.scss']
})
export class DashboardBodySubtitleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
